import { Options } from './types';
export declare function embedImages<T extends HTMLElement>(clonedNode: T, options: Options): Promise<void>;
