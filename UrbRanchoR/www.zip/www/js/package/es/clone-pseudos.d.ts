export declare function clonePseudoElements<T extends HTMLElement>(nativeNode: T, clonedNode: T): void;
