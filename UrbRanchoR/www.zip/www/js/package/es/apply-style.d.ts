import { Options } from './types';
export declare function applyStyle<T extends HTMLElement>(node: T, options: Options): T;
